# EZaccounting (Aplikasi Accounting Sederhana) Dengan PHP, MySQL dan Bootstrap 3

Cara pakai :
1. Import dulu file "ezaccounting.sql" di folder "database" ke xampp
2. Masuk ke "localhost/ezaccounting/index.php" melalui browser
3. Silahkan login menggunakan user default :
	- ID		: admin 
	- PASSWORD	: admin123
4. Pilihan menu :
	a. menu Transaksi untuk menampilkan, memfilter, menambah, mengubah, menghapus entry Debit Credit.
	b. menu Admin untuk menampilkan, memfilter, menambah, mengubah, menghapus entry User.
	c. menu Laporan untuk menampilkan, memfilter data Debit Credit.
	d. menu Logout untuk keluar dari halaman admin