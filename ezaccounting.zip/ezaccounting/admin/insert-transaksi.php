<?php

/*
$con=mysql_connect("localhost","root","") or die("Gagal");
mysql_select_db("ecommerce")  or die("Gagal");*/
include "../conn.php";

		$trans_id		= $_POST['trans_id'];
		$information	= $_POST['information'];
		$note			= $_POST['note'];
		$debit			= $_POST['debit'];
		$credit			= $_POST['credit'];
        $date_input		= date("Y-m-d H:i:s");
        $date_edit		= date("Y-m-d H:i:s");
        
		global $koneksi;
		$sql="INSERT INTO transaction(trans_id,information,note,debit,credit,date_input,date_edit) VALUES
		(NULL,'$information','$note','$debit','$credit','$date_input','$date_edit')";
			
if ($koneksi->query($sql) === TRUE) {
		header('Location: transaksi.php');
	} else {
		echo "Error : " . $koneksi->error;
	}


?>