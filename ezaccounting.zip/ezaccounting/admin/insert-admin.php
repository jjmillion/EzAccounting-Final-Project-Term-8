<?php

/*
$con=mysql_connect("localhost","root","") or die("Gagal");
mysql_select_db("ecommerce")  or die("Gagal");*/
include "../conn.php";


        $user_id = $_POST['user_id'];
		$username= $_POST['username'];
		$password=$_POST['password'];
        $level=$_POST['level'];
		
			global $koneksi;
			$sql="INSERT INTO user(user_id,username,password,level) VALUES
            (NULL ,'$username','$password','$level')";
			
if ($koneksi->query($sql) === TRUE) {
		echo 'Data berhasil ditambahkan!';
		header('Location: input-admin.php');
	} else {
		echo "Error : " . $koneksi->error;
	}


?>