<?php
include "../conn.php";

		$trans_id		= $_POST['trans_id'];
		$information	= $_POST['information'];
		$note			= $_POST['note'];
		$debit			= $_POST['debit'];
		$credit			= $_POST['credit'];
        $date_edit		= date("Y-m-d H:i:s");

global $koneksi;
$query = mysqli_query($koneksi, "UPDATE transaction SET information='$information', note='$note', debit='$debit', credit='$credit', date_edit='$date_edit' WHERE trans_id='$trans_id'")or die(mysql_error());
if ($query){
header('location:transaksi.php');	
} else {
	echo "gagal";
    }
?>