<?php
include "../conn.php";
$trans_id = $_GET['kd'];

$query = mysqli_query($koneksi, "DELETE FROM transaction WHERE trans_id='$trans_id'");
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = 'transaksi.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = 'transaksi.php'</script>";	
}
?>