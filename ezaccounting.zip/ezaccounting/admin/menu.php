                    <br />
                    <ul class="sidebar-menu">
                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-usd"></i> <span>Transaksi</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="transaksi.php"><i class="fa fa-angle-double-right"></i>Data Transaksi</a></li>
                                <li><a href="input-transaksi.php"><i class="fa fa-angle-double-right"></i>Tambah Transaksi</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-lock"></i> <span>Admin</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="admin.php"><i class="fa fa-angle-double-right"></i>Data Admin</a></li>
                                <li><a href="input-admin.php"><i class="fa fa-angle-double-right"></i>Tambah Admin</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-file"></i> <span>Laporan</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="laporan-balance.php"><i class="fa fa-angle-double-right"></i>Laporan Balance</a></li>
                            </ul>
                        </li>

                        <li class="active">
                             <a href="../logout.php"><i class="glyphicon glyphicon-lock" ;></i> Log Out </a>
                        </li></ul>
                    
                       
                        
                        